#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void bubbleSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; ++i) {
        for (int j = 0; j < n - i - 1; ++j) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
}

int main() {
    ifstream inFile("rand_numb.txt");
    if (!inFile) {
        cerr << "Error: Unable to open input file." << endl;
        return 1;
    }

    vector<int> numbers;
    int num;
    while (inFile >> num) {
        numbers.push_back(num);
    }
    inFile.close();

    bubbleSort(numbers);

    ofstream outFile("sorted_numbers.txt");
    if (!outFile) {
        cerr << "Error: Unable to open output file." << endl;
        return 1;
    }

    for (int i = 0; i < numbers.size(); ++i) {
        outFile << numbers[i] << endl;
    }
    outFile.close();

    cout << "Numbers have been sorted using bubble sort and stored in 'sorted_numbers.txt'." << endl;

    return 0;
}

