
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    srand(time(nullptr));

    int n;
    cout << "Enter the number of random numbers to generate: ";
    cin >> n;

    ofstream outFile("rand_numb.txt");

    if (!outFile) {
        cerr << "Error: Unable to open file." << endl;
        return 1;
    }

    for (int i = 0; i < n; ++i) {
        outFile << rand() << endl;
    }

    outFile.close();

    cout << "Random numbers have been generated and stored in 'rand_numb.txt'." << endl;

    return 0;
}
