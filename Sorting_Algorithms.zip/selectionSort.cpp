#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void selectionSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; ++i) {
        int minIndex = i;
        for (int j = i + 1; j < n; ++j) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        if (minIndex != i) {
            swap(arr[i], arr[minIndex]);
        }
    }
}

int main() {
    ifstream inFile("rand_numb.txt");
    if (!inFile) {
        cerr << "Error: Unable to open input file." << endl;
        return 1;
    }

    vector<int> numbers;
    int num;
    while (inFile >> num) {
        numbers.push_back(num);
    }
    inFile.close();

    selectionSort(numbers);

    ofstream outFile("sorted_numbers.txt");
    if (!outFile) {
        cerr << "Error: Unable to open output file." << endl;
        return 1;
    }

    for (int i = 0; i < numbers.size(); ++i) {
        outFile << numbers[i] << endl;
    }
    outFile.close();

    cout << "Numbers have been sorted using selection sort and stored in 'sorted_numbers.txt'." << endl;

    return 0;
}
