
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void insertionSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 1; i < n; ++i) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

int main() {
    ifstream inFile("rand_numb.txt");
    if (!inFile) {
        cerr << "Error: Unable to open input file." << endl;
        return 1;
    }

    vector<int> numbers;
    int num;
    while (inFile >> num) {
        numbers.push_back(num);
    }
    inFile.close();

    insertionSort(numbers);

    ofstream outFile("sorted_numbers.txt");
    if (!outFile) {
        cerr << "Error: Unable to open output file." << endl;
        return 1;
    }

    for (int i = 0; i < numbers.size(); ++i) {
        outFile << numbers[i] << endl;
    }
    outFile.close();

    cout << "Numbers have been sorted and stored in 'sorted_numbers.txt'." << endl;

    return 0;
}
